package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskRequestAdapter(private val task: List<Task>) :
    RecyclerView.Adapter<TaskRequestAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewTitle: TextView = itemView.findViewById(R.id.textViewTitle)
        val textViewName: TextView = itemView.findViewById(R.id.textViewName)
        val textViewDetails: TextView = itemView.findViewById(R.id.textViewDetails)
        val textViewModel: TextView = itemView.findViewById(R.id.textViewModel)
        val textViewPhotos : TextView = itemView.findViewById(R.id.textViewPhotos)
        // Add other TextViews or UI elements as needed
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskRequestAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task_request, parent, false)
        return TaskRequestAdapter.ViewHolder(view)
    }
    override fun onBindViewHolder(holder: TaskRequestAdapter.ViewHolder, position: Int) {
        val taskRequest = task[position]
        holder.textViewTitle.text = taskRequest.taskTitle
        holder.textViewName.text =taskRequest.taskName
        holder.textViewDetails.text =taskRequest.taskDetails
        holder.textViewModel.text =taskRequest.taskModel
        holder.textViewPhotos.text = taskRequest.taskPhotos.toString()

    // Bind other data to UI elements as needed
    }
    override fun getItemCount(): Int {
        return task.size
    }
    }