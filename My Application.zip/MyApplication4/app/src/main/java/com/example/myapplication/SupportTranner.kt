package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class SupportTranner : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_support_tranner)

        FirebaseApp.initializeApp(this)

        // Get the current user ID
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        if (userId != null) {
            // Use the user ID to create a reference to the user's support requests
            val databaseReference = FirebaseDatabase.getInstance().getReference("supportRequests/$userId")

            // Get values from UI elements
            val editTextReason = findViewById<EditText>(R.id.editTextReason)
            val datePicker = findViewById<DatePicker>(R.id.datePicker1)
            val timePicker = findViewById<TimePicker>(R.id.timePicker)
            val btnApply = findViewById<Button>(R.id.btnApply)

            btnApply.setOnClickListener {

            val reason = editTextReason.text.toString()
            // Extract date and time from DatePicker and TimePicker
            val year = datePicker.year
            val month = datePicker.month + 1 // Month is zero-based
            val day = datePicker.dayOfMonth
            val hour = timePicker.hour
            val minute = timePicker.minute

            // Create a SupportRequest object
                val supportRequest = SupportRequest(
                    id = null,  // You can pass null or generate an appropriate value for the id
                    reason = reason,
                    year = year,
                    month = month,
                    day = day,
                    hour = hour,
                    minute = minute,
                     // Replace with the actual value for the additional field
                )
            // Push the data to Firebase under the user's supportRequests node
            databaseReference.push().setValue(supportRequest)
                val intent = Intent(this@SupportTranner, TaskDetails::class.java)
                startActivity(intent)
                finish()
            }
        } else {
            // Handle the case where the user is not authenticated
            // You might want to redirect them to the login screen or take appropriate action
            // For now, let's log a message
            println("User not authenticated")
        }
    }
}
