package com.example.myapplication.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.SupportRequest
import com.example.myapplication.SupportRequestAdapter
import com.example.myapplication.databinding.FragmentDashboardBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DashboardFragment : Fragment() {
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private lateinit var supportRequestList: MutableList<SupportRequest>
    private lateinit var recyclerView: RecyclerView
    private lateinit var supportRequestAdapter: SupportRequestAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Initialize RecyclerView
        recyclerView = root.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize supportRequestList and set up the adapter
        supportRequestList = mutableListOf()
        supportRequestAdapter = SupportRequestAdapter(supportRequestList)
        recyclerView.adapter = supportRequestAdapter

        // Get the current user ID
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        if (userId != null) {
            // Use the user ID to create a reference to the user's support requests
            val databaseReference = FirebaseDatabase.getInstance().getReference("supportRequests/$userId")

            // Attach a ValueEventListener to fetch the user's support requests
            databaseReference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    // Clear previous data
                    supportRequestList.clear()

                    // Process the support requests and update the list
                    for (childSnapshot in dataSnapshot.children) {
                        val request = childSnapshot.getValue(SupportRequest::class.java)
                        request?.let {
                            supportRequestList.add(it)
                        }
                    }

                    // Notify the adapter of the data change
                    supportRequestAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle errors
                }
            })
        } else {
            // Handle the case where the user is not authenticated
            // You might want to redirect them to the login screen or take appropriate action
            // For now, let's log a message
            println("User not authenticated")
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
