import com.example.myapplication.User

import com.example.myapplication.Dog

class DogOwner(
    name: String,
    email: String,
    password: String,
    var dogs: List<Dog>,
    var trainingProgress: String
) : User(name = name, email = email, password = password) {
    // Rest of the class code



    override fun login() {
        // Implementation for login specific to DogOwner
    }

    fun manageDogs() {
        // Implementation for managing dogs
    }

    fun viewTrainingProgress() {
        // Implementation for viewing training progress
    }
}
