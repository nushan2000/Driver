package com.example.myapplication

class UserFeedback(
    var trainer: Trainer,

    var rating: Int,
    var comments: String
) {
    fun submitFeedback() {
        // Implementation for submitting feedback
    }
}