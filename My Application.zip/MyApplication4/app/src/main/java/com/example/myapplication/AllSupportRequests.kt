package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AllSupportRequestActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var supportRequestAdapter: SupportRequestAdapter
    private lateinit var supportRequestList: MutableList<SupportRequest>

    // Reference to Realtime Database
    private val databaseReference: DatabaseReference =
        FirebaseDatabase.getInstance().getReference("supportRequests")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_support_requests)

        // Initialize RecyclerView and Adapter
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize supportRequestList and set up the adapter
        supportRequestList = mutableListOf()
        supportRequestAdapter = SupportRequestAdapter(supportRequestList)
        recyclerView.adapter = supportRequestAdapter

        // Add a ValueEventListener to listen for changes in the "supportRequests" node
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                Log.d("Firebase Database", "onDataChange triggered")
                // Clear previous data
                supportRequestList.clear()

                // Process the support requests and update the list
                for (userSnapshot in dataSnapshot.children) {
                    for (childSnapshot in userSnapshot.children) {
                        val request = childSnapshot.getValue(SupportRequest::class.java)
                        request?.let {
                            supportRequestList.add(it)
                        }
                    }
                }

                // Notify the adapter of the data change
                supportRequestAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle errors
                Log.e(
                    "Firebase Database",
                    "Error getting support requests",
                    databaseError.toException()
                )
            }
        })
    }
}
