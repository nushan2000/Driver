package com.example.myapplication

class TrainingProgram(
    var programName: String,
    var description: String,
    var duration: Int,
    var level: String
) {
    val sessions: MutableList<TrainingSession> = mutableListOf()

    fun viewDetails() {
        // Implementation for viewing program details
    }

    fun viewSessions() {
        // Implementation for viewing sessions
    }

    fun enroll() {
        // Implementation for enrollment
    }
}