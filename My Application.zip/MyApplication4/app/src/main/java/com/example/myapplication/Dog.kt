package com.example.myapplication

class Dog(
    var name: String,
    var breed: String,
    var age: Int,
    var currentTrainingLevel: String,
    var healthInformation: String
) {
    fun viewProgress() {
        // Implementation for viewing progress
    }

    fun scheduleSession() {
        // Implementation for scheduling a session
    }

    fun viewHealthInformation() {
        // Implementation for viewing health information
    }
}