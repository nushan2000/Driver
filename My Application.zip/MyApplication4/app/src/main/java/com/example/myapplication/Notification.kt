package com.example.myapplication

class Notification(
    var message: String,
    var sender: User,
    var receiver: User,
    var timestamp: String
) {
    fun sendNotification() {
        // Implementation for sending a notification
    }

    fun receiveNotification() {
        // Implementation for receiving a notification
    }
}