package com.example.myapplication;

import android.app.Activity;

public class BlankFragment extends Activity {
}
