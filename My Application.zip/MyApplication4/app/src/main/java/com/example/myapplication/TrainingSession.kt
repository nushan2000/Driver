package com.example.myapplication

class TrainingSession(
    var date: String,
    var time: String,
    var location: String,
    var trainer: Trainer,

) {
    fun viewDetails() {
        // Implementation for viewing session details
    }

    fun attendSession() {
        // Implementation for attending a session
    }

    fun provideFeedback() {
        // Implementation for providing feedback
    }
}