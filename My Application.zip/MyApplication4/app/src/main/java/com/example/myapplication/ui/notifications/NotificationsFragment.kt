package com.example.myapplication.ui.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R


import com.example.myapplication.Task
import com.example.myapplication.TaskRequestAdapter
import com.example.myapplication.databinding.FragmentNotificationsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class NotificationsFragment : Fragment() {

    private lateinit var binding: FragmentNotificationsBinding
    private lateinit var completedTasksList: MutableList<Task>
    private lateinit var recyclerView: RecyclerView
    private lateinit var completedTasksAdapter: TaskRequestAdapter
    // This property is only valid between onCreateView and
    // onDestroyView.


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Initialize RecyclerView
        recyclerView = root.findViewById(R.id.recyclerViews)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize supportRequestList and set up the adapter
        completedTasksList = mutableListOf()
        completedTasksAdapter = TaskRequestAdapter(completedTasksList)
        recyclerView.adapter = completedTasksAdapter

        // Get the current user ID
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        if (userId != null) {
            // Use the user ID to create a reference to the user's support requests
            val completedTasksReference =FirebaseDatabase.getInstance().getReference("completedTasks/$userId")

            completedTasksReference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    // Clear previous data
                    completedTasksList.clear()
                    for (childSnapshot in dataSnapshot.children) {
                        val completedTask = childSnapshot.getValue(Task::class.java)
                        completedTask?.let {
                            // Check if the task is completed
                            if (it.taskStatus == "completed") {
                                completedTasksList.add(it)
                            }
                        }

                        // Notify the adapter of the data change
                        completedTasksAdapter.notifyDataSetChanged()
                    }
                }
                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle errors
                }
            })
        } else {
            // Handle the case where the user is not authenticated
            // You might want to redirect them to the login screen or take appropriate action
            // For now, let's log a message
            println("User not authenticated")
        }

        return root
    }


}

