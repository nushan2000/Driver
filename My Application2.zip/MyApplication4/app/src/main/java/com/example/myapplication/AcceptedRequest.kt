package com.example.myapplication

data class AcceptedRequest(
    val id: String,
    val reason: String,
    val year: Int,
    val month: Int,
    val day: Int,
    val hour: Int,
    val minute: Int,
    val status: String

)