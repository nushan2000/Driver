package com.example.myapplication

class TrainingSession(
    var date: String,
    var time: String,
    var location: String,
    var trainer: Trainer,

) {
    fun viewDetails() {

    }

    fun attendSession() {

    }

    fun provideFeedback() {

    }
}