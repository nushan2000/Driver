package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity

class TrainerDashboard : AppCompatActivity() {

}
